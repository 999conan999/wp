<?php
require_once(get_stylesheet_directory().'/templates/archive/archive.php');
?>