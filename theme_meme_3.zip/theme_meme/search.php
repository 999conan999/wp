<?php
require_once(get_stylesheet_directory().'/templates/search/search.php');
?>