<?php
require_once(get_stylesheet_directory().'/templates/404/404.php');
?>