<?php
require_once(get_stylesheet_directory().'/templates/footer/footer.php');
?>