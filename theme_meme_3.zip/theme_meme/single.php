<?php
require_once(get_stylesheet_directory().'/templates/single/single.php');
?>