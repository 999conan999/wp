<?php
require_once(get_stylesheet_directory().'/templates/page/page.php');
?>